var Entity;
var EntityId;

ZOHO.embeddedApp.on("PageLoad", function (data) {
    console.log("Testing: ",data);
    Entity = data.Entity;
    EntityId = data.EntityId;
    ZOHO.CRM.API.getRecord({ Entity: Entity, RecordID: EntityId })
      .then(function (data) {
        console.log("DATA",data)
        console.log(data.data[0].Full_Name)
        console.log(data.data[0].Email)
        // alert("this is a data");
      })
  })
   ZOHO.embeddedApp.init();